# Vulnerability Management Lab

**Goal:** Show end-to-end vuln lifecycle: discovery → triage → remediation → verification.

## Tools
- **Nessus Essentials** (local scans)
- **Qualys** (if available)

## Workflow
1. Scope a lab host (VM) and run baseline scan
2. Triage high/critical findings by CVSS and exploitability
3. Remediate (patch/config change)
4. Re-scan & verify

## Deliverables
- Scan reports (sanitized)
- Triage spreadsheet (CVE, severity, owner, ETA)
- Remediation proof (before/after screenshots, config)
- Brief write-up using the included template
