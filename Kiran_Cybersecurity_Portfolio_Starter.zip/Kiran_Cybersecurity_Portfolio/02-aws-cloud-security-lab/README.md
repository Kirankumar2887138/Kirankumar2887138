# AWS Cloud Security Lab

**Goal:** Demonstrate security configuration & monitoring on AWS.

## Modules
1. **Identity & Access Management (IAM)** — least privilege, MFA, access analyzer
2. **Logging & Monitoring** — CloudTrail, CloudWatch, GuardDuty, Security Hub
3. **Network Protections** — VPC flow logs, NACLs, security groups
4. **Application Protection** — AWS WAF basic rules
5. **Compliance View** — Security Hub standards

## Deliverables
- Step-by-step setup with screenshots
- Terraform/CloudFormation snippets (optional)
- Findings reports from GuardDuty/Security Hub
- Remediation notes + before/after

## Suggested Evidence
`/artifacts/` → JSON exports, screenshots, policy docs
