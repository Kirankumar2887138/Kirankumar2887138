# Incident Runbook Template

**Scenario:**  
**Detection Source:** (Splunk/Sentinel)  
**Severity:** Low/Medium/High/Critical

## 1. Triage
- Validate alert context
- Check related events / users / hosts

## 2. Containment
- Disable account / revoke keys / isolate host

## 3. Eradication & Recovery
- Patch / reset creds / restore from backup

## 4. Post-Incident
- Root cause
- Preventive actions
