# Incident Write-up Template

**Date:**  
**Scenario:**  
**MITRE ATT&CK:** Tactic/Technique IDs

## Summary
One paragraph overview.

## Evidence
Screenshots, queries, hashes, timestamps.

## Impact
Systems, users, data affected.

## Lessons Learned
- 
- 
