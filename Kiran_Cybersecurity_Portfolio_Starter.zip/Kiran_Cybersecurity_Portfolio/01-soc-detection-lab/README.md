# SOC Detection Lab

**Goal:** Show end-to-end alerting + response using Splunk and Microsoft Sentinel.

## Skills
- Log onboarding (syslog/CloudTrail/Azure diagnostics)
- **SPL** and **KQL** query writing
- Alert tuning (false positive reduction)
- Incident response (triage → containment → eradication → recovery)
- MITRE ATT&CK mapping

## Lab Scenarios (add one per subfolder)
1. **Brute-force login** (Linux SSH or IAM user)  
2. **Suspicious AWS API usage** (CreateAccessKey, DisableTrail)  
3. **Exfil via unusual S3 object gets**  
4. **Impossible travel** sign-in (Azure Entra)  

## Structure
```
scenarios/
  01-ssh-bruteforce/
    data/                  # sample logs (sanitized)
    queries/               # SPL + KQL
    detections/            # saved searches/analytics rules (exported)
    runbook.md             # response steps
    writeup.md             # findings + lessons
screenshots/
dashboards/                # exported JSONs
scripts/                   # helper parsers
```

## Reproduce (example)
- Spin up Splunk Free or Trial / Microsoft Sentinel (Microsoft Learn sandbox).
- Use provided sample logs in `scenarios/*/data` or generate with tools (e.g., `auth.log` replay).
- Import queries and dashboards, trigger detections, and capture screenshots.

## Artifacts to Include
- Queries (SPL/KQL)
- Dashboard exports
- Alert rules
- Runbooks & post-incident reports
