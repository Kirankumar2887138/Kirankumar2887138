# GRC Policy Pack (NIST CSF / 800-53)

**Goal:** Demonstrate governance skills with lightweight but professional artifacts.

## Contents
- `policies/` — Acceptable Use, Access Control, Incident Response, Vulnerability Mgmt
- `standards/` — Baselines (e.g., CIS controls summary)
- `procedures/` — Joiner-Mover-Leaver, Access Review, Patch Management
- `risk-register.xlsx` — Example entries with likelihood/impact and mitigations
- `traceability/` — Mapping to **NIST CSF** functions and **800-53** controls

Use the templates here and tailor per scenario.
