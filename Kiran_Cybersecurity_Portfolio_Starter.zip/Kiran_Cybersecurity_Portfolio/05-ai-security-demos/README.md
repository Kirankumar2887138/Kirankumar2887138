# AI Security Demos

**Goal:** Show awareness of LLM/AI risks and practical defenses.

## Mini-Projects
1. **Prompt Injection Detector** — rules/regex + context isolation demo
2. **PII Egress Guard** — simple middleware to mask or block sensitive output
3. **Threat Model** — Data flow diagram + MITRE **ATLAS** mapping

## Evidence
- Code samples (Python/Node)
- Test cases showing blocked attacks
- Short write-ups
